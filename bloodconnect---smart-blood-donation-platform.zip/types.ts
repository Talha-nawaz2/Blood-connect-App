
export enum BloodType {
  A_POS = 'A+',
  A_NEG = 'A-',
  B_POS = 'B+',
  B_NEG = 'B-',
  AB_POS = 'AB+',
  AB_NEG = 'AB-',
  O_POS = 'O+',
  O_NEG = 'O-'
}

export enum UrgencyLevel {
  LOW = 'Low',
  MEDIUM = 'Medium',
  HIGH = 'High',
  CRITICAL = 'Critical'
}

export interface Donor {
  id: string;
  name: string;
  bloodType: BloodType;
  location: string;
  lastDonationDate: string;
  isAvailable: boolean;
  contact: string;
  distance?: number;
}

export interface BloodRequest {
  id: string;
  patientName: string;
  bloodType: BloodType;
  hospital: string;
  urgency: UrgencyLevel;
  requiredUnits: number;
  contact: string;
  createdAt: string;
  status: 'Pending' | 'Matched' | 'Fulfilled';
}
