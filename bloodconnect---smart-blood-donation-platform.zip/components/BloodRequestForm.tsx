
import React, { useState } from 'react';
import { BloodType, UrgencyLevel } from '../types';

interface BloodRequestFormProps {
  onSubmit: (data: any) => void;
}

const BloodRequestForm: React.FC<BloodRequestFormProps> = ({ onSubmit }) => {
  const [formData, setFormData] = useState({
    patientName: '',
    bloodType: BloodType.O_POS,
    hospital: '',
    urgency: UrgencyLevel.MEDIUM,
    requiredUnits: 1,
    contact: '',
    notes: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6 bg-white p-8 rounded-2xl shadow-xl border border-slate-100">
      <h2 className="text-2xl font-bold text-slate-800 mb-6">Create Urgent Request</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Patient Name</label>
          <input
            required
            type="text"
            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-red-500 outline-none"
            value={formData.patientName}
            onChange={(e) => setFormData({...formData, patientName: e.target.value})}
            placeholder="John Doe"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Blood Type Required</label>
          <select
            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-red-500 outline-none"
            value={formData.bloodType}
            onChange={(e) => setFormData({...formData, bloodType: e.target.value as BloodType})}
          >
            {Object.values(BloodType).map(t => <option key={t} value={t}>{t}</option>)}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Hospital / Clinic</label>
          <input
            required
            type="text"
            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-red-500 outline-none"
            value={formData.hospital}
            onChange={(e) => setFormData({...formData, hospital: e.target.value})}
            placeholder="KTH Peshawar"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Urgency Level</label>
          <select
            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-red-500 outline-none"
            value={formData.urgency}
            onChange={(e) => setFormData({...formData, urgency: e.target.value as UrgencyLevel})}
          >
            {Object.values(UrgencyLevel).map(u => <option key={u} value={u}>{u}</option>)}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Units Needed</label>
          <input
            required
            type="number"
            min="1"
            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-red-500 outline-none"
            value={formData.requiredUnits}
            onChange={(e) => setFormData({...formData, requiredUnits: parseInt(e.target.value)})}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Contact Phone</label>
          <input
            required
            type="tel"
            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-red-500 outline-none"
            value={formData.contact}
            onChange={(e) => setFormData({...formData, contact: e.target.value})}
            placeholder="+92 XXX XXXXXXX"
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-slate-700 mb-1">Case Description (for Smart Matching)</label>
        <textarea
          className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-red-500 outline-none"
          rows={3}
          value={formData.notes}
          onChange={(e) => setFormData({...formData, notes: e.target.value})}
          placeholder="Briefly describe the situation for our AI triage..."
        ></textarea>
      </div>

      <button
        type="submit"
        className="w-full py-4 bg-red-600 text-white rounded-xl font-bold text-lg hover:bg-red-700 transition-all shadow-lg hover:shadow-red-200"
      >
        Submit Emergency Request
      </button>
    </form>
  );
};

export default BloodRequestForm;
