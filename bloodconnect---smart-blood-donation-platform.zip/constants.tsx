
import React from 'react';
import { BloodType, Donor, UrgencyLevel, BloodRequest } from './types';

export const COMPATIBILITY_CHART: Record<BloodType, BloodType[]> = {
  [BloodType.O_NEG]: [BloodType.O_NEG, BloodType.O_POS, BloodType.A_NEG, BloodType.A_POS, BloodType.B_NEG, BloodType.B_POS, BloodType.AB_NEG, BloodType.AB_POS],
  [BloodType.O_POS]: [BloodType.O_POS, BloodType.A_POS, BloodType.B_POS, BloodType.AB_POS],
  [BloodType.A_NEG]: [BloodType.A_NEG, BloodType.A_POS, BloodType.AB_NEG, BloodType.AB_POS],
  [BloodType.A_POS]: [BloodType.A_POS, BloodType.AB_POS],
  [BloodType.B_NEG]: [BloodType.B_NEG, BloodType.B_POS, BloodType.AB_NEG, BloodType.AB_POS],
  [BloodType.B_POS]: [BloodType.B_POS, BloodType.AB_POS],
  [BloodType.AB_NEG]: [BloodType.AB_NEG, BloodType.AB_POS],
  [BloodType.AB_POS]: [BloodType.AB_POS],
};

export const MOCK_DONORS: Donor[] = [
  { id: '1', name: 'Shaheer Ud Din', bloodType: BloodType.O_POS, location: 'Hayatabad, Peshawar', lastDonationDate: '2023-10-12', isAvailable: true, contact: '+92-300-1234567', distance: 2.5 },
  { id: '2', name: 'Talha Nawaz', bloodType: BloodType.A_POS, location: 'University Road, Peshawar', lastDonationDate: '2024-01-05', isAvailable: true, contact: '+92-311-9876543', distance: 4.1 },
  { id: '3', name: 'Abdul Mohaiman', bloodType: BloodType.B_NEG, location: 'Warsak Road, Peshawar', lastDonationDate: '2023-11-20', isAvailable: false, contact: '+92-345-0001112', distance: 1.2 },
  { id: '4', name: 'Salim Aziz', bloodType: BloodType.O_NEG, location: 'Dabgari Garden, Peshawar', lastDonationDate: '2024-02-15', isAvailable: true, contact: '+92-322-3334445', distance: 0.8 },
  { id: '5', name: 'Zainab Bibi', bloodType: BloodType.AB_POS, location: 'Ring Road, Peshawar', lastDonationDate: '2023-12-01', isAvailable: true, contact: '+92-301-2223334', distance: 3.7 },
];

export const MOCK_REQUESTS: BloodRequest[] = [
  { id: 'r1', patientName: 'Ahmad Khan', bloodType: BloodType.A_POS, hospital: 'Khyber Teaching Hospital', urgency: UrgencyLevel.CRITICAL, requiredUnits: 3, contact: '091-5844441', createdAt: '2024-05-20T10:00:00Z', status: 'Pending' },
  { id: 'r2', patientName: 'Sara Ali', bloodType: BloodType.O_NEG, hospital: 'Lady Reading Hospital', urgency: UrgencyLevel.HIGH, requiredUnits: 1, contact: '091-9211430', createdAt: '2024-05-19T14:30:00Z', status: 'Matched' },
];
