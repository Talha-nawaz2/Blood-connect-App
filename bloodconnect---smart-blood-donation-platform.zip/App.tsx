
import React, { useState, useEffect } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import BloodRequestForm from './components/BloodRequestForm';
import StatCard from './components/StatCard';
import { MOCK_DONORS, MOCK_REQUESTS, COMPATIBILITY_CHART } from './constants';
import { BloodType, Donor, BloodRequest, UrgencyLevel } from './types';
import { getSmartMatchingAdvise } from './geminiService';

const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState('home');
  const [donors, setDonors] = useState<Donor[]>(MOCK_DONORS);
  const [requests, setRequests] = useState<BloodRequest[]>(MOCK_REQUESTS);
  const [matchingResult, setMatchingResult] = useState<{ matches: Donor[], advise: string } | null>(null);
  const [isMatching, setIsMatching] = useState(false);

  const handleRequestSubmit = async (data: any) => {
    setIsMatching(true);
    setCurrentPage('match');
    
    const newRequest: BloodRequest = {
      id: `r${requests.length + 1}`,
      patientName: data.patientName,
      bloodType: data.bloodType,
      hospital: data.hospital,
      urgency: data.urgency,
      requiredUnits: data.requiredUnits,
      contact: data.contact,
      createdAt: new Date().toISOString(),
      status: 'Pending',
    };
    
    setRequests([newRequest, ...requests]);

    // Simulate Smart Matching
    const compatibleTypes = COMPATIBILITY_CHART[data.bloodType];
    const matches = donors.filter(d => d.isAvailable && compatibleTypes.includes(d.bloodType));
    
    const advise = await getSmartMatchingAdvise(data.bloodType, data.urgency, data.hospital);
    
    setMatchingResult({ matches, advise });
    setIsMatching(false);
  };

  const inventoryData = Object.values(BloodType).map(type => ({
    name: type,
    units: Math.floor(Math.random() * 20) + 5
  }));

  const COLORS = ['#ef4444', '#f87171', '#dc2626', '#b91c1c', '#991b1b', '#7f1d1d', '#fecaca', '#fee2e2'];

  const renderHome = () => (
    <div className="space-y-12 pb-20">
      <Hero 
        onDonate={() => setCurrentPage('donors')} 
        onRequest={() => setCurrentPage('requests')} 
      />
      
      <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          label="Total Donors" 
          value={donors.length} 
          color="bg-red-50 text-red-600"
          icon={<svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" /></svg>}
        />
        <StatCard 
          label="Pending Requests" 
          value={requests.filter(r => r.status === 'Pending').length} 
          color="bg-orange-50 text-orange-600"
          icon={<svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>}
        />
        <StatCard 
          label="Lives Saved" 
          value="1,240+" 
          color="bg-green-50 text-green-600"
          icon={<svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" /></svg>}
        />
        <StatCard 
          label="Average Match Time" 
          value="18 mins" 
          color="bg-blue-50 text-blue-600"
          icon={<svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>}
        />
      </div>

      <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <h3 className="text-xl font-bold mb-6 flex items-center">
            <span className="w-2 h-8 bg-red-600 rounded-full mr-3"></span>
            Real-time Blood Inventory (Peshawar)
          </h3>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={inventoryData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="units" fill="#ef4444" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
        
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <h3 className="text-xl font-bold mb-6 flex items-center">
            <span className="w-2 h-8 bg-orange-500 rounded-full mr-3"></span>
            Demand by Type
          </h3>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={inventoryData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={5}
                  dataKey="units"
                >
                  {inventoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );

  const renderRequests = () => (
    <div className="max-w-5xl mx-auto px-4 py-12">
      <div className="mb-12">
        <h2 className="text-3xl font-extrabold text-slate-900 mb-4">Urgent Blood Requests</h2>
        <p className="text-slate-500">Every request here is verified. If you can help, please reach out immediately.</p>
      </div>

      <div className="grid grid-cols-1 gap-8">
        <div className="bg-slate-50 p-1 rounded-2xl">
          <BloodRequestForm onSubmit={handleRequestSubmit} />
        </div>

        <div className="space-y-4 mt-8">
          <h3 className="text-xl font-bold text-slate-800">Active Requests</h3>
          {requests.map((req) => (
            <div key={req.id} className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="flex items-center space-x-4">
                <div className={`w-14 h-14 rounded-full flex items-center justify-center font-bold text-xl ${
                  req.urgency === UrgencyLevel.CRITICAL ? 'bg-red-100 text-red-600' : 'bg-slate-100 text-slate-600'
                }`}>
                  {req.bloodType}
                </div>
                <div>
                  <h4 className="font-bold text-slate-900">{req.patientName}</h4>
                  <p className="text-sm text-slate-500">{req.hospital}</p>
                </div>
              </div>
              <div className="flex items-center space-x-8">
                <div className="text-center">
                  <p className="text-xs text-slate-400 uppercase font-semibold">Urgency</p>
                  <p className={`font-bold ${req.urgency === UrgencyLevel.CRITICAL ? 'text-red-600 animate-pulse' : 'text-slate-600'}`}>{req.urgency}</p>
                </div>
                <div className="text-center">
                  <p className="text-xs text-slate-400 uppercase font-semibold">Units</p>
                  <p className="font-bold">{req.requiredUnits}</p>
                </div>
                <button className="bg-slate-900 text-white px-6 py-2 rounded-lg font-semibold hover:bg-slate-800 transition-colors">
                  Contact
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderDonors = () => (
    <div className="max-w-5xl mx-auto px-4 py-12">
      <div className="flex justify-between items-center mb-12">
        <div>
          <h2 className="text-3xl font-extrabold text-slate-900 mb-4">Our Hero Donors</h2>
          <p className="text-slate-500">Volunteers ready to save lives at a moment's notice.</p>
        </div>
        <button className="bg-red-600 text-white px-6 py-3 rounded-xl font-bold hover:bg-red-700 shadow-lg">
          Register as Donor
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {donors.map(donor => (
          <div key={donor.id} className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 hover:shadow-md transition-all">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 rounded-xl bg-red-50 text-red-600 flex items-center justify-center font-bold">
                  {donor.bloodType}
                </div>
                <div>
                  <h4 className="font-bold text-slate-900">{donor.name}</h4>
                  <p className="text-xs text-slate-400">{donor.location}</p>
                </div>
              </div>
              <div className={`px-2 py-1 rounded text-xs font-bold ${donor.isAvailable ? 'bg-green-100 text-green-700' : 'bg-slate-100 text-slate-500'}`}>
                {donor.isAvailable ? 'Available' : 'Unavailable'}
              </div>
            </div>
            <div className="flex justify-between text-sm pt-4 border-t">
              <span className="text-slate-500">Last donated: {donor.lastDonationDate}</span>
              <span className="text-red-600 font-medium">{donor.distance} km away</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderSmartMatch = () => (
    <div className="max-w-5xl mx-auto px-4 py-12">
      {isMatching ? (
        <div className="flex flex-col items-center justify-center h-[60vh]">
          <div className="w-20 h-20 border-4 border-red-600 border-t-transparent rounded-full animate-spin"></div>
          <p className="mt-8 text-xl font-bold text-slate-700">AI is finding the best matches...</p>
          <p className="text-slate-400">Analyzing compatibility, location, and urgency.</p>
        </div>
      ) : matchingResult ? (
        <div className="space-y-8">
          <div className="bg-gradient-to-r from-red-600 to-red-800 p-8 rounded-3xl text-white shadow-xl relative overflow-hidden">
             <div className="absolute top-0 right-0 p-4 opacity-10">
                <svg className="w-32 h-32" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" clipRule="evenodd" /></svg>
             </div>
             <h2 className="text-3xl font-bold mb-4">Smart Match Results</h2>
             <div className="bg-white/10 backdrop-blur-md p-4 rounded-xl border border-white/20">
                <p className="font-medium text-red-50 italic">" {matchingResult.advise} "</p>
             </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h3 className="text-xl font-bold text-slate-800">Best Matching Donors</h3>
              {matchingResult.matches.length > 0 ? (
                matchingResult.matches.map(donor => (
                  <div key={donor.id} className="bg-white p-6 rounded-2xl shadow-sm border border-red-100 flex items-center justify-between group hover:border-red-500 transition-all cursor-pointer">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-red-600 text-white rounded-full flex items-center justify-center font-bold ring-4 ring-red-50">
                        {donor.bloodType}
                      </div>
                      <div>
                        <h4 className="font-bold text-slate-900">{donor.name}</h4>
                        <p className="text-xs text-slate-500">{donor.distance} km away • {donor.location}</p>
                      </div>
                    </div>
                    <button className="bg-red-50 text-red-600 p-3 rounded-full hover:bg-red-600 hover:text-white transition-colors">
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" /></svg>
                    </button>
                  </div>
                ))
              ) : (
                <div className="bg-white p-8 rounded-2xl text-center border border-dashed border-slate-300">
                  <p className="text-slate-500">No exact matches found. Expanding search criteria...</p>
                </div>
              )}
            </div>

            <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100">
               <h3 className="text-xl font-bold text-slate-800 mb-4">Compatibility Guide</h3>
               <div className="space-y-4">
                  <div className="flex items-center p-3 bg-blue-50 text-blue-700 rounded-lg text-sm">
                    <svg className="w-5 h-5 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" /></svg>
                    <span>Our system uses Gemini AI to rank donors based on real-time availability and proximity.</span>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-slate-200">
                       <thead className="bg-slate-50">
                          <tr>
                             <th className="px-3 py-2 text-left text-xs font-bold text-slate-500 uppercase">Type</th>
                             <th className="px-3 py-2 text-left text-xs font-bold text-slate-500 uppercase">Can Give To</th>
                          </tr>
                       </thead>
                       <tbody className="divide-y divide-slate-100 text-sm">
                          {Object.entries(COMPATIBILITY_CHART).slice(0, 5).map(([type, targets]) => (
                            <tr key={type}>
                               <td className="px-3 py-2 font-bold text-red-600">{type}</td>
                               <td className="px-3 py-2 text-slate-600">{targets.join(', ')}</td>
                            </tr>
                          ))}
                       </tbody>
                    </table>
                  </div>
               </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="text-center py-20">
          <div className="w-20 h-20 bg-red-100 text-red-600 rounded-full flex items-center justify-center mx-auto mb-6">
            <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
          </div>
          <h2 className="text-2xl font-bold text-slate-900 mb-2">No active matching session</h2>
          <p className="text-slate-500 mb-8">Submit a blood request to start the smart matching process.</p>
          <button 
            onClick={() => setCurrentPage('requests')}
            className="bg-red-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-red-700"
          >
            Create Request
          </button>
        </div>
      )}
    </div>
  );

  const renderContent = () => {
    switch(currentPage) {
      case 'home': return renderHome();
      case 'requests': return renderRequests();
      case 'donors': return renderDonors();
      case 'match': return renderSmartMatch();
      default: return renderHome();
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar onNavigate={setCurrentPage} currentPage={currentPage} />
      
      <main className="flex-grow">
        {renderContent()}
      </main>

      <footer className="bg-slate-900 text-white py-12 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <div>
              <div className="flex items-center mb-6">
                <div className="h-8 w-8 bg-red-600 rounded-full flex items-center justify-center mr-2">
                  <div className="h-4 w-4 bg-white rounded-sm rotate-45"></div>
                </div>
                <span className="text-2xl font-bold tracking-tight">BloodConnect</span>
              </div>
              <p className="text-slate-400">Department of Computer Science, University of Engineering & Technology, Peshawar. Project 2025.</p>
            </div>
            <div>
              <h4 className="text-lg font-bold mb-6">Quick Links</h4>
              <ul className="space-y-4 text-slate-400">
                <li><button onClick={() => setCurrentPage('home')} className="hover:text-red-500">Home</button></li>
                <li><button onClick={() => setCurrentPage('donors')} className="hover:text-red-500">Find Donors</button></li>
                <li><button onClick={() => setCurrentPage('requests')} className="hover:text-red-500">Submit Request</button></li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-bold mb-6">Contact Us</h4>
              <p className="text-slate-400 mb-2">Phone: +92 91 1234567</p>
              <p className="text-slate-400 mb-2">Email: support@bloodconnect.pk</p>
              <p className="text-slate-400">Location: UET Peshawar Campus</p>
            </div>
          </div>
          <div className="mt-12 pt-8 border-t border-slate-800 text-center text-slate-500 text-sm">
            © 2025 BloodConnect. Built by Shaheer, Talha, Mohaiman, and Salim Aziz. Supervisor: Ms. Kanwal Aneeq.
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
