
import { GoogleGenAI, Type } from "@google/genai";
import { BloodType, Donor, UrgencyLevel } from "./types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const getSmartMatchingAdvise = async (bloodType: BloodType, urgency: UrgencyLevel, hospital: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Suggest a strategy for a ${urgency} blood request of type ${bloodType} at ${hospital}. Briefly explain the urgency and which donor groups should be prioritized. Keep it under 100 words.`,
      config: {
        thinkingConfig: { thinkingBudget: 0 }
      }
    });
    return response.text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Prioritize O-Negative donors for immediate critical needs while verifying compatibility for other available donors.";
  }
};

export const getCompatibilityExplanation = async (userBloodType: BloodType) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Explain who blood type ${userBloodType} can donate to and receive from in a simple table-like format for a patient portal.`,
      config: {
         thinkingConfig: { thinkingBudget: 0 }
      }
    });
    return response.text;
  } catch (error) {
    return "O- is the universal donor, while AB+ is the universal recipient.";
  }
};
